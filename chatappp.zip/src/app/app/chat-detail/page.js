import React from 'react'
import SignupForm from '@/app/components/WebChat/ChatSignup/ChatDetail'
const page = () => {
  return (
    <div>
      <SignupForm/>
      </div>
  )
}

export default page