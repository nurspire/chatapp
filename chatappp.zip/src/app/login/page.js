import React from 'react'
import LoginSignupPage from '../components/Login/Login'
const page = () => {
  return (
    <div>
        <LoginSignupPage/>
    </div>
  )
}

export default page