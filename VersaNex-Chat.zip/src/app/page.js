import React from 'react'
import Home from './components/Home/home'
const page = () => {
  return (
    <div>
     <Home/>
    </div>
  )
}

export default page