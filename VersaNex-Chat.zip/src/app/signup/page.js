import React from 'react'
import SignupPage from '../components/Signup/SignUp'
const page = () => {
  return (
    <div><SignupPage/></div>
  )
}

export default page